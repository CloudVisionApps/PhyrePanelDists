<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Minecraft\\App\\Providers\\MinecraftServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Minecraft\\App\\Providers\\MinecraftServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);