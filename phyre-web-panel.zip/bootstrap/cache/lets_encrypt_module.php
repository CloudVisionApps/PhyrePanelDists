<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\LetsEncrypt\\App\\Providers\\LetsEncryptServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\LetsEncrypt\\App\\Providers\\LetsEncryptServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);