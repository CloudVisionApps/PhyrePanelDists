<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Microweber\\App\\Providers\\MicroweberServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Microweber\\App\\Providers\\MicroweberServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);