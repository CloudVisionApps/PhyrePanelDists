<?php

namespace App;

class ApiClient
{
    public static function getPhyrePHP()
    {
        return '/usr/local/phyre/php/bin/php';
    }
}
