<?php

namespace app\Filament\Resources\DomainResource\Pages;

use App\Filament\Resources\DomainResource;
use Filament\Resources\Pages\EditRecord;
use Filament\Resources\Pages\ViewRecord;

class EditDomain extends EditRecord
{
    protected static string $resource = DomainResource::class;


}
