<?php

namespace Modules\SSLManager\App\Filament\Resources\CertificateResource\Pages;

use Modules\SSLManager\App\Filament\Resources\CertificateResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCertificate extends CreateRecord
{
    protected static string $resource = CertificateResource::class;
}
