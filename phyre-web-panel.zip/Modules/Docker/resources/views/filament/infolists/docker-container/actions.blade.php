<div>
    {{ $getAction('stop') }}
    {{ $getAction('start') }}
    {{ $getAction('restart') }}
    {{ $getAction('recreate') }}
    {{ $getAction('delete') }}
</div>
