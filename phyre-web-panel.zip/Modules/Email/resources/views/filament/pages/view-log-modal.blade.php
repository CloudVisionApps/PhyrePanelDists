<pre style="max-width: 100%; max-height: 100vh; overflow: auto;">
    {{ $logContents }}
</pre>

