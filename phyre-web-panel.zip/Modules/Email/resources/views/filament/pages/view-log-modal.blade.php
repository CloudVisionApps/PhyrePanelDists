<pre style="max-width: 100%; max-height: 500px; overflow: auto;font-size:12px">
    {{ $logContents }}
</pre>

