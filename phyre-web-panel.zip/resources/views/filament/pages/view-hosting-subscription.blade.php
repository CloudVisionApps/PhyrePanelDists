<x-filament-panels::page>

    <div>
       {{-- hostingSubscriptionId="{{$this->data['id']}}"--}}
        <livewire:file-manager />
    </div>

</x-filament-panels::page>
