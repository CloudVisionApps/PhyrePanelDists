<x-filament-panels::page>

  <div>

      <x-filament::button
             wire:click="startUpdate"
          class="mb-4">
            {{ __('Update to the latest version') }}
      </x-filament::button>

  </div>

</x-filament-panels::page>
