@php
echo "
<?php

echo file_get_contents('templates/index.html');

?>"

@endphp
